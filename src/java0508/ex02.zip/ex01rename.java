/*
  
  Date : 2020.05.08
  Author :booltaeliya
  Description : Java 기본설정
  Version : 1.0
  
 
 
  
*/

package java0508;

public class ex01rename {
	public static void main(String[] args) {

		// 주석달기
		// 1. 한줄 주석처리
		/* 2. 범위 주석처리 */

		System.out.println("Bool Tae LiYa");
		System.out.println("Bool Tae LiYa");
		// sysout 입력후 [ctrl]+[space]
		System.out.println();
		System.out.println("sysout입력후[ctrl+space] ");

		// 실행run =>>[ctrl] + [F11]
		// 저장(save)=>>[ctrl] + [s]
		// 모두 저장(Save all) =>>[ctrl + shift +s]
		// 글자 크게 : [ctrl]+[+]
		// 글자 작게 : [ctrl]+[-]
		/*
		 * 클래스 이름바꾸기 "클래스명" 오른쪽마우스 >Refactor>Rename
		 * 
		 * 프로젝트, 패키지 동일
		 * 
		 */

	}

}
