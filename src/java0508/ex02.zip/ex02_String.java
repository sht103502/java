package java0508;

public class ex02_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "자바 공부는 ";
		String str2 = "재미있다";
		String str3 = "너무 어려워";

		String result; // 변수 선언

		result = str1 + str2; // 변수 초기화
		System.out.println(result);

		result = str1 + str3; // 변수초기화
		System.out.println(result);

		result = str1 + 8.0;
		System.out.println(result);

		System.out.println(str1 + str2);
		System.out.println(str1 + "너무너무" + str2);

	}

}
