package java0508;

public class ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 
		int age1;
		age1= 35;
		int age2=11,age3=12,age4=13;
		
		//1+1 =2;
		age1= 10;
		//10을 age1에 대입 한다.
		
	}

}
