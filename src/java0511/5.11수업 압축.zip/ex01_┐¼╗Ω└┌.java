/*
  
  Date : 2020.05.11
  Author : 신희태
  Description : 연산자(Operation)
  Version : 1.0
*/

package java0511;

public class ex01_연산자 {

	public static void main(String[] args) {
		//연산자 : 프로그램을 짤 때 변수나 값의 연산을 
		//위해 사용되는부호
		//수학시간 사용했던 +, -, x, /등등
		
		//단항연산자 : 항이 한개인 연산자
		//증감연산자 
		
		//이항연산자 : 향이 두개인 연산자
		//산술연산자, 관계연산자, 논리연산자
		
		//삼항연산자 : 향이 세개인 연산자
		//조건연산자
	}

}
