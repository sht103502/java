/*
  Date : 2020.05.13
  Author :신희태
  Description :  반복문 for(loopFor)
  Version : 1.0
*/
package java0513;

public class ex01_loopFor {

	public static void main(String[] args) {
		/*
		 	for(초기화식; 조건식; 증감식) {
		 		반복할 수행문 
		 	}
		 */	
		 	for(int i=1; i<=10; i++) {
		 		System.out.println(i);
		 		System.out.println("반복문 종료후 i값:" + i);
		 	}
		
		 	
	}

}
