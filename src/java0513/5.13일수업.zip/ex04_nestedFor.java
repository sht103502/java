/*
  Date : 2020.05.13
  Author :신희태
  Description :  중첩for 문
  Version : 1.3
*/
package java0513;

public class ex04_nestedFor {

	public static void main(String[] args) {
		// 중첩for문
		/*
		  
		  for(초기화식; 조건식; 증감식) { 
		 
		 	for(초기화식; 조건식; 증감식){
		 		실행할 반본문 
		 	}
		  }
		 
		 */
		for(int i=1; i<=2; i++) {
			
			
			// 1
			
			// 2
			
			
			
			
			
			
			
			for(int j=1; j<=3; j++) {
				//실행할 반복문
				System.out.print("i값:" + i);
				System.out.println("j값:" + j); 
				// 1 1
				// 1 2
				// 1 3
				
				
			}
			System.out.println("=============");
			
			
			
			
			
			
			
		}
		
		
		
		
		
		
	}

}
