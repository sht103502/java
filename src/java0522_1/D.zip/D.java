package java0522_1;

import java0522.A;

public class D {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A a=new A();
		a.public1=10;
//		a.proteced1=10;
//		a.default1=10;
//		a.private1= 10;
		
		a.public2();
//		a.protected2();
//		a.default2();
//		a.private2();
		
	}

}
